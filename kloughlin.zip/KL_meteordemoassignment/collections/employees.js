// new employee database
Employee = new Meteor.Collection('employee');

Employee.remove({});

Employee.insert({
  "employee_number": "200",
  "first_name": "Eric",
  "office_phone": "312-405-3112",
  "cell":"312-332-4555",
  "last_name": "Williams",
  "email" : "ewilliams@myfs.com",
  "location" : "Chicago,IL",
  "dept" : "Sales",
  "title": "VP",
  "bio": "I have been with FS for 10 years all in Sales."
});

Employee.insert({
  "employee_number": "90",
  "first_name": "Mary",
  "office_phone": "651-405-3115",
  "cell":"651-335-4534",
  "last_name": "Rose",
  "email" : "mrose@myfs.com",
  "location" : "Minneapolis,MN",
  "dept" : "Marketing",
  "title": "Director",
  "bio": "I have been with FS for 25 years all in Marketings."
});

Employee.insert({
  "employee_number": "542",
  "first_name": "Tom",
  "office_phone": "623-490-4523",
  "cell":"623-366-7890",
  "last_name": "Bridges",
  "email" : "tbridges@myfs.com",
  "location" : "Phoenix, AZ",
  "dept" : "Technology",
  "title": "Senior Manager",
  "bio": "I have been with FS for 5 years all in Technology."
});

Employee.insert({
  "employee_number": "501",
  "first_name": "Lou",
  "office_phone": "718-490-2423",
  "cell":"718-360-7891",
  "last_name": "Stone",
  "email" : "lstone@myfs.com",
  "location" : "Rochester, NY",
  "dept" : "Sales",
  "title": "Senior Manager",
  "bio": "I have been with FS for 8 years all in Sales."
});

Employee.insert({
  "employee_number": "620",
  "first_name": "Pam",
  "office_phone": "312-490-4523",
  "cell":"312-366-7890",
  "last_name": "Jones",
  "email" : "pjones@myfs.com",
  "location" : "Chicago,IL",
  "dept" : "Finance",
  "title": "Auditor",
  "bio": "I have been with FS for 4 years all in Finance."
});

Employee.insert({
  "employee_number": "655",
  "first_name": "Harry",
  "office_phone": "614-490-4523",
  "cell":"614-366-7890",
  "last_name": "Smith",
  "email" : "hsmith@myfs.com",
  "location" : "Columbus, OH",
  "dept" : "Operations",
  "title": "Center Manager",
  "bio": "I have been with FS for 2 years all in the Columbus Center."
});
