Template.ManageExistingEmployee.onCreated(function(){
    var self = this;
    self.autorun(function(){
        self.subscribe('employee');
    });
});


// Template.ManageExistingEmployee.events({
//
// });

Template.ManageExistingEmployee.events({
    click: function() {
      return Employee.find();
      console.log('I clicked something');
    }
  });



// Template.ManageExistingEmployee.helpers({
//
// });

Template.ManageExistingEmployee.helpers({
    employee: function() {
      return Employee.find();
    },
    selectedClass:function(){
      return selected ();
    }
});
