console.log('client side javascript is working. Yea!');
